﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
     namespace kt7_lisaYakimova
    {
        internal class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("УРОВЕНЬ 1: БАЗОВЫЕ ЗАДАНИЯ");

                Console.WriteLine("\n1. точки на плоскости:");
                Point point1 = new Point(3, 2);
                Point point2 = new Point(2, 1);

                Console.Write("точка 1: ");
                point1.PrintCoordinates();
                Console.Write("точка 2: ");
                point2.PrintCoordinates();

                Console.WriteLine($"расстояние по X: {point2.X - point1.X}");
                Console.WriteLine($"расстояние по Y: {point2.Y - point1.Y}");

                Console.WriteLine("\n2. прямоугольник:");
                Rectangle rectangle = new Rectangle(5, 2);
                Console.WriteLine($"прямоугольник: ширина={rectangle.Width}, высота={rectangle.Height}");
                Console.WriteLine($"площадь: {rectangle.CalculateArea()}");
                Console.WriteLine($"периметр: {rectangle.CalculatePerimeter()}");

                Console.WriteLine("\n3.книга:");
                Book book = new Book("капитанская дочка", "Александр Пушкин", 1836);
                book.PrintBookInfo();

                Console.WriteLine("УРОВЕНЬ 2: СРЕДНИЕ ЗАДАНИЯ");

                Console.WriteLine("\n4. комплексные числа:");
                ComplexNumber num1 = new ComplexNumber(2, 3);
                ComplexNumber num2 = new ComplexNumber(1, 4);

                Console.WriteLine($"число 1: {num1}");
                Console.WriteLine($"число 2: {num2}");

                ComplexNumber sum = num1.Add(num2);
                ComplexNumber difference = num1.Subtract(num2);
                ComplexNumber product = num1.Multiply(num2);

                Console.WriteLine($"Сложение: {num1} + {num2} = {sum}");
                Console.WriteLine($"Вычитание: {num1} - {num2} = {difference}");
                Console.WriteLine($"Умножение: {num1} * {num2} = {product}");

                Console.WriteLine("\n5. Цвет RGB:");
                Color red = new Color(255, 0, 0);
                Color green = new Color(0, 255, 0);
                Color blue = new Color(0, 0, 255);
                Color purple = new Color(128, 0, 128);

                Console.WriteLine("цвета:");
                Console.WriteLine($"красный: {red.ToHex()}");
                Console.WriteLine($"зеленый: {green.ToHex()}");
                Console.WriteLine($"синий: {blue.ToHex()}");
                Console.WriteLine($"фиолетовый: {purple.ToHex()}");

                Console.WriteLine("\nRGB значения:");
                red.PrintRGB();
                green.PrintRGB();

                Console.WriteLine("\n6. дата и високосные годы:");
                SimpleDate date1 = new SimpleDate(15, 2, 2021);
                SimpleDate date2 = new SimpleDate(15, 2, 2025);
                SimpleDate date3 = new SimpleDate(15, 2, 2000);
                SimpleDate date4 = new SimpleDate(15, 2, 1996);

                Console.WriteLine($"{date1} - високосный: {date1.IsLeapYear()}");
                Console.WriteLine($"{date2} - високосный: {date2.IsLeapYear()}");
                Console.WriteLine($"{date3} - високосный: {date3.IsLeapYear()}");
                Console.WriteLine($"{date4} - високосный: {date4.IsLeapYear()}");

                Console.WriteLine("УРОВЕНЬ 3: ПРОДВИНУТЫЕ ЗАДАНИЯ");

                Console.WriteLine("\n7. вектор в 2D:");
                Vector2D vector = new Vector2D(3, 4);
                Vector2D vector2 = new Vector2D(1, 2);

                Console.WriteLine($"вектор 1: {vector}");
                Console.WriteLine($"вектор 2: {vector2}");
                Console.WriteLine($"длина вектора 1: {vector.Length():F2}");
                Console.WriteLine($"нормализованный вектор 1: {vector.Normalize()}");
                Console.WriteLine($"скалярное произведение: {vector.Dot(vector2)}");

                Console.WriteLine("\n8. деньги:");
                Money money1 = new Money(5, 96);
                Money money2 = new Money(3, 150);
                Money money3 = new Money(7, 23);

                Console.WriteLine($"деньги 1: {money1}");
                Console.WriteLine($"деньги 2: {money2}");
                Console.WriteLine($"деньги 3: {money3}");
                Console.WriteLine($"сумма 1 + 2: {money1.Add(money2)}");
                Console.WriteLine($"разница 1 - 3: {money1.Subtract(money3)}");
                Console.WriteLine($"деньги 1 > деньги 3: {money1.IsGreaterThan(money3)}");
                Console.WriteLine($"деньги 3 < деньги 2: {money3.IsLessThan(money2)}");

                Console.WriteLine("\n9. треугольник:");
                Point pointA = new Point(0, 0);
                Point pointB = new Point(4, 0);
                Point pointC = new Point(0, 3);

                Triangle triangle = new Triangle(pointA, pointB, pointC);
                var sides = triangle.GetSideLengths();
                Console.WriteLine($"Вершины: A{pointA}, B{pointB}, C{pointC}");
                Console.WriteLine($"Стороны: AB={sides.ab:F2}, BC={sides.bc:F2}, CA={sides.ca:F2}");
                Console.WriteLine($"Периметр: {triangle.GetPerimeter():F2}");
                Console.WriteLine($"Площадь: {triangle.GetArea():F2}");

                Console.WriteLine("\n10. 3D-геометрия:");
                Point3D point3D1 = new Point3D(1, 2, 3);
                Point3D point3D2 = new Point3D(4, 6, 8);
                Point3D point3D3 = new Point3D(0, 0, 0);

                Console.WriteLine($"Точка 1: {point3D1}");
                Console.WriteLine($"Точка 2: {point3D2}");
                Console.WriteLine($"Точка 3: {point3D3}");
                Console.WriteLine($"Расстояние 1-2: {point3D1.DistanceTo(point3D2):F2}");
                Console.WriteLine($"Расстояние 1-3: {point3D1.DistanceTo(point3D3):F2}");

                Console.WriteLine("\nНажмите любую клавишу для выхода...");
                Console.ReadKey();
            }
        }

        public struct Point
        {
            public int X;
            public int Y;

            public Point(int x, int y)
            {
                X = x;
                Y = y;
            }

            public void PrintCoordinates()
            {
                Console.WriteLine($"координаты: X={X}, Y={Y}");
            }
        }

        public struct Rectangle
        {
            public int Width;
            public int Height;

            public Rectangle(int width, int height)
            {
                Width = width;
                Height = height;
            }

            public int CalculateArea()
            {
                return Width * Height;
            }

            public int CalculatePerimeter()
            {
                return 2 * (Width + Height);
            }
        }

        public struct Book
        {
            public string Title;
            public string Author;
            public int Year;

            public Book(string title, string author, int year)
            {
                Title = title;
                Author = author;
                Year = year;
            }

            public void PrintBookInfo()
            {
                Console.WriteLine($"{Title} — {Author} ({Year})");
            }
        }

        public struct ComplexNumber
        {
            public double Real;
            public double Imag;

            public ComplexNumber(double real, double imag)
            {
                Real = real;
                Imag = imag;
            }

            public ComplexNumber Add(ComplexNumber other)
            {
                return new ComplexNumber(Real + other.Real, Imag + other.Imag);
            }

            public ComplexNumber Subtract(ComplexNumber other)
            {
                return new ComplexNumber(Real - other.Real, Imag - other.Imag);
            }

            public ComplexNumber Multiply(ComplexNumber other)
            {
                double newReal = Real * other.Real - Imag * other.Imag;
                double newImag = Real * other.Imag + Imag * other.Real;
                return new ComplexNumber(newReal, newImag);
            }

            public override string ToString()
            {
                return $"{Real} + {Imag}i";
            }
        }

        public struct Color
        {
            public byte R;
            public byte G;
            public byte B;

            public Color(byte r, byte g, byte b)
            {
                R = r;
                G = g;
                B = b;
            }

            public string ToHex()
            {
                return $"#{R:X2}{G:X2}{B:X2}";
            }

            public void PrintRGB()
            {
                Console.WriteLine($"RGB: ({R}, {G}, {B})");
            }
        }

        public struct SimpleDate
        {
            public int Day;
            public int Month;
            public int Year;

            public SimpleDate(int day, int month, int year)
            {
                Day = day;
                Month = month;
                Year = year;
            }

            public bool IsLeapYear()
            {
                if (Year % 400 == 0) return true;
                if (Year % 100 == 0) return false;
                if (Year % 4 == 0) return true;
                return false;
            }

            public override string ToString()
            {
                return $"{Day:00}.{Month:00}.{Year}";
            }
        }

        public struct Vector2D
        {
            public double X;
            public double Y;

            public Vector2D(double x, double y)
            {
                X = x;
                Y = y;
            }

            public double Length()
            {
                return Math.Sqrt(X * X + Y * Y);
            }

            public Vector2D Normalize()
            {
                double length = Length();
                if (length == 0) return new Vector2D(0, 0);
                return new Vector2D(X / length, Y / length);
            }

            public double Dot(Vector2D other)
            {
                return X * other.X + Y * other.Y;
            }

            public override string ToString()
            {
                return $"({X}, {Y})";
            }
        }

        public struct Money
        {
            public int Rubles;
            public int Kopecks;

            public Money(int rubles, int kopecks)
            {
                Rubles = rubles;
                Kopecks = kopecks;
                Normalize();
            }

            private void Normalize()
            {
                if (Kopecks >= 100)
                {
                    Rubles += Kopecks / 100;
                    Kopecks = Kopecks % 100;
                }

                if (Kopecks < 0 && Rubles > 0)
                {
                    Rubles -= 1;
                    Kopecks += 100;
                }
            }

            public Money Add(Money other)
            {
                return new Money(Rubles + other.Rubles, Kopecks + other.Kopecks);
            }

            public Money Subtract(Money other)
            {
                return new Money(Rubles - other.Rubles, Kopecks - other.Kopecks);
            }

            public bool IsGreaterThan(Money other)
            {
                int thisTotal = Rubles * 100 + Kopecks;
                int otherTotal = other.Rubles * 100 + other.Kopecks;
                return thisTotal > otherTotal;
            }

            public bool IsLessThan(Money other)
            {
                int thisTotal = Rubles * 100 + Kopecks;
                int otherTotal = other.Rubles * 100 + other.Kopecks;
                return thisTotal < otherTotal;
            }

            public override string ToString()
            {
                return $"{Rubles} руб. {Kopecks:00} коп.";
            }
        }

        public struct Triangle
        {
            public Point A;
            public Point B;
            public Point C;

            public Triangle(Point a, Point b, Point c)
            {
                A = a;
                B = b;
                C = c;
            }

            public (double ab, double bc, double ca) GetSideLengths()
            {
                double sideAB = Distance(A, B);
                double sideBC = Distance(B, C);
                double sideCA = Distance(C, A);
                return (sideAB, sideBC, sideCA);
            }

            private double Distance(Point p1, Point p2)
            {
                double dx = p1.X - p2.X;
                double dy = p1.Y - p2.Y;
                return Math.Sqrt(dx * dx + dy * dy);
            }

            public double GetPerimeter()
            {
                var sides = GetSideLengths();
                return sides.ab + sides.bc + sides.ca;
            }

            public double GetArea()
            {
                var sides = GetSideLengths();
                double p = GetPerimeter() / 2;
                return Math.Sqrt(p * (p - sides.ab) * (p - sides.bc) * (p - sides.ca));
            }
        }

        public struct Point3D
        {
            public double X;
            public double Y;
            public double Z;

            public Point3D(double x, double y, double z)
            {
                X = x;
                Y = y;
                Z = z;
            }

            public double DistanceTo(Point3D other)
            {
                double dx = X - other.X;
                double dy = Y - other.Y;
                double dz = Z - other.Z;
                return Math.Sqrt(dx * dx + dy * dy + dz * dz);
            }

            public override string ToString()
            {
                return $"({X}, {Y}, {Z})";
            }
        }
    }
