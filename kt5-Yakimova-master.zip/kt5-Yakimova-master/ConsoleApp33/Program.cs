﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp33
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Card card = new card();
            Cash cash = new cash();
            Card.pay();
            Cash.pay();
        }
    }
}
    public interface IPayment
    {
        void pay();
    }
public class Card : IPayment
{
    public void pay()
    {
        Console.WriteLine("You paid by card");
    }
}
    public class Cash : IPayment
    {
        public void Say()
        {
            Console.WriteLine("You paid by cash");
        }
    }



