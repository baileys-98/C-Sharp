﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKKT
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("демонстрация конструкторов класса с книгами:");
            book book1 = new book();
            Console.WriteLine("книга 1 (конструктор по умолчанию):");
            book1.DisplayInfo();
            book book2 = new book("Гарри Поттер и философский камень", "Джоан Роулинг", 1997);
            Console.WriteLine("книга 2 (параметрический конструктор):");
            book2.DisplayInfo();
            book book3 = new book("Властелин Колец", "Джон Толкин");
            Console.WriteLine("книга 3 (конструктор с двумя параметрами):");
            book3.DisplayInfo();
            book book4 = new book("Маленький принц", "Антуан де Сент-Экзюпери", 1943);
            Console.WriteLine("Книга 4:");
            book4.DisplayInfo();
            book book5 = new book("Алиса в Стране чудес", "Льюис Кэрролл");
            Console.WriteLine("Книга 5 (современная книга):");
            book5.DisplayInfo();

        }
    }

    public class book
    {

        public string Title { get; set; }
        public string Author { get; set; }
        public int Year { get; set; }
        public book()
        {
            Title = "-";
            Author = "-";
            Year = 2024;
        }
        public book(string title, string author, int year)
        {
            Title = title;
            Author = author;
            Year = year;
        }
        public book(string title, string author)
        {
            Title = title;
            Author = author;
            Year = 2024;
        }
        public void DisplayInfo()
        {
            Console.WriteLine($"Книга: {Title}");
            Console.WriteLine($"Автор: {Author}");
            Console.WriteLine($"Год издания: {Year}");
            Console.ReadKey();
        }
    }

}