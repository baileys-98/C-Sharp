﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KT_masage
{

}
    public interface INotifier
    {
        void Send(string message);
    }

    public class EmailNotifier : INotifier
    {
        public void Send(string message)
        {
            Console.WriteLine($"Отправка Email: {message}");
        }
    }

    public class SmsNotifier : INotifier
    {
        public void Send(string message)
        {
            Console.WriteLine($"Отправка SMS: {message}");
        }
    }

    public class TelegramNotifier : INotifier
    {
        public void Send(string message)
        {
            Console.WriteLine($"Отправка Telegram: {message}");
        }
    }
class Program
{
    static void Main(string[] args)
    {
        List<INotifier> notifiers = new List<INotifier>
        {
            new EmailNotifier(),
            new SmsNotifier(),
            new TelegramNotifier()
        };

        foreach (var notifier in notifiers)
        {
            notifier.Send("Интерфейсы эт крутаааа!");
        }
    }
}


